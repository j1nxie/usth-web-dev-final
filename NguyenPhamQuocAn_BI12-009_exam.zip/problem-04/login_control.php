<html>
    <body>
        Welcome <?php echo $_POST["username"]; ?>
    </body>
</html>